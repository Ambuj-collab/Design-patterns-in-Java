package com.company.depinv;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {

	public static void main(String[] args) throws IOException {
		
		Message msg = new Message("This is a message again");
		MessagePrinter printer = new MessagePrinter();
		
		try(PrintWriter writer = new PrintWriter(new FileWriter("test_msg.txt"))) {    // message will be printed on the specified fileName
			printer.writeMessage(msg, new JSONFormatter(), writer);
		}			
		
        /*		
		try(PrintWriter writer = new PrintWriter(System.out)) {    // message will be printed on console
			printer.writeMessage(msg, new JSONFormatter(), writer);
		}
		*/
	}

}
