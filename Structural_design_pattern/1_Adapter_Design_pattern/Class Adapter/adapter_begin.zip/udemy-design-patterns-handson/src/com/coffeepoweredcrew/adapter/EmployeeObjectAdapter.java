package com.coffeepoweredcrew.adapter;

/**
 * An object adapter. Using composition to translate interface
 */
public class EmployeeObjectAdapter {
		
}
