package com.coffeepoweredcrew.adapter;

/**
 * A class adapter, works as Two-way adapter
 */
public class EmployeeClassAdapter {
	
}
