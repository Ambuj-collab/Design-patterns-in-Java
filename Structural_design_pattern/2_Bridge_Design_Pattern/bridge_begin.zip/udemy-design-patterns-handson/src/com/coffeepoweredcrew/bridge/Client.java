package com.coffeepoweredcrew.bridge;

public class Client {

	public static void main(String[] args) {
		
	}

}
