package com.coffeepoweredcrew.bridge;

//A refined abstraction.
public class Queue<T> {
	
	
}
