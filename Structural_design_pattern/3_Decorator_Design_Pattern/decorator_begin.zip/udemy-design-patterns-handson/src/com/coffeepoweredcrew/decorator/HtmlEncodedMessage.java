package com.coffeepoweredcrew.decorator;

//Decorator. Implements component interface
public class HtmlEncodedMessage {

}
