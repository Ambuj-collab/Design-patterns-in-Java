package com.coffeepoweredcrew.singleton;

public class Client {

	public static void main(String[] args) {

	}

}
